# TensorFlow Lite Swift API Test App

The TensorFlow Lite Swift API usage can be found in various iOS example apps
provided in the following locations.

*   [TensorFlow Lite example apps](https://www.tensorflow.org/lite/examples)
*   [tensorflow/examples Repository](https://github.com/tensorflow/examples)
